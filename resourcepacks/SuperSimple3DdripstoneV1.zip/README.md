# Super Simple 3D Dripstone
This pack makes pointed dripstone 3D using new 3D models that make use of the dripstone block texture.
Allowing pointed dripstone to look good no matter the resource pack you use it with.
